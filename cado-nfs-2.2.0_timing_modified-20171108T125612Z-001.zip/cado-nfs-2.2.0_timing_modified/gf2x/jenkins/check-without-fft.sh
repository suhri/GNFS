DISABLE_FFT=1
. "`dirname $0`"/check-generic.sh
