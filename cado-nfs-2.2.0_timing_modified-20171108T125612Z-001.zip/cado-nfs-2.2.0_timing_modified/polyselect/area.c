#include "area.h"

double area = AREA, bound_f = BOUND_F, bound_g = BOUND_G;
