int cachesize_cpuid (int verbose);
