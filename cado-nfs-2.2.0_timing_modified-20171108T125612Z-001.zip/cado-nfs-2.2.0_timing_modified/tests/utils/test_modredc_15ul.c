#include "cado.h"
#define ARITHMETIC "modredc_15ul_default.h"
#include "test_mod.c"
