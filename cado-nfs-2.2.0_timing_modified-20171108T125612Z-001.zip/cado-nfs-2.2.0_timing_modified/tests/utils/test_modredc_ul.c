#include "cado.h"
#define ARITHMETIC "modredc_ul_default.h"
#include "test_mod.c"
