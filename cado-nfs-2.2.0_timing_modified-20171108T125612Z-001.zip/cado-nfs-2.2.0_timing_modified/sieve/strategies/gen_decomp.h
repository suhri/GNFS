#ifndef GEN_DECOMP_H
#define  GEN_DECOMP_H

#include "tab_decomp.h"

tabular_decomp_t*
generate_all_decomp (int mfb, unsigned long lim);

#endif /* GEN_DECOMP_H */
