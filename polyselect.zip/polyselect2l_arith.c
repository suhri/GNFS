#include "cado.h"
#include "polyselect2l_arith.h"
#include "polyselect2l_str.h"
#include "portability.h"

/* return 1/a mod p, assume 0 <= a < p */
unsigned long
invert (unsigned long a, unsigned long p)
{
  modulusul_t q;
  residueul_t b;

  modul_initmod_ul (q, p);
  modul_init (b, q);
  assert (a < p);
  modul_set_ul_reduced (b, a, q);
  modul_inv (b, b, q);
  a = modul_get_ul (b, q);
  modul_clear (b, q);
  modul_clearmod (q);
  return a;
}


/* lift the n roots r[0..n-1] of N = x^d (mod p) to roots of
   N = (m0 + r)^d (mod p^2) */
void
roots_lift (uint64_t *r, mpz_t N, unsigned long d, mpz_t m0,
            unsigned long p, unsigned long n)
{
  uint64_t pp;
  unsigned long j, inv;
  mpz_t tmp, lambda;
  mpz_init (tmp);
  mpz_init (lambda);
  pp = (uint64_t) p;
  pp *= (uint64_t) p;

  if (sizeof (unsigned long) == 8) {
    for (j = 0; j < n; j++) {
	/* we have for r=r[j]: r^d = N (mod p), lift mod p^2:
	   (r+lambda*p)^d = N (mod p^2) implies
	   r^d + d*lambda*p*r^(d-1) = N (mod p^2)
	   lambda = (N - r^d)/(p*d*r^(d-1)) mod p */
	mpz_ui_pow_ui (tmp, r[j], d - 1);
	mpz_mul_ui (lambda, tmp, r[j]);    /* lambda = r^d */
	mpz_sub (lambda, N, lambda);
	mpz_divexact_ui (lambda, lambda, p);
	mpz_mul_ui (tmp, tmp, d);         /* tmp = d*r^(d-1) */
	inv = invert (mpz_fdiv_ui (tmp, p), p);
	mpz_mul_ui (lambda, lambda, inv * p); /* inv * p fits in 64 bits if
						 p < 2^32 */
	mpz_add_ui (lambda, lambda, r[j]); /* now lambda^d = N (mod p^2) */

	/* subtract m0 to get roots of (m0+r)^d = N (mod p^2) */
	mpz_sub (lambda, lambda, m0);
	r[j] = mpz_fdiv_ui (lambda, pp);
      }
  }
  else {
#if 0   
    printf ("p: %lu, ppl %" PRId64 ": ", p, pp);
#endif
    uint64_t tmp1;
    mpz_t ppz, *rz, tmpz;
    rz = (mpz_t*) malloc (n * sizeof (mpz_t));
    mpz_init (ppz);
    mpz_init (tmpz);
    for (j = 0; j < n; j++) {
      mpz_init_set_ui (rz[j], 0UL);
      mpz_set_uint64 (rz[j], r[j]);
#if 0   
      printf (" %" PRIu64 "", r[j]);
#endif
    }

    for (j = 0; j < n; j++) {
	mpz_pow_ui (tmp, rz[j], d - 1);
	mpz_mul (lambda, tmp, rz[j]);    /* lambda = r^d */
	mpz_sub (lambda, N, lambda);
	mpz_divexact_ui (lambda, lambda, p);
	mpz_mul_ui (tmp, tmp, d);         /* tmp = d*r^(d-1) */
	inv = invert (mpz_fdiv_ui (tmp, p), p);
	tmp1 = (uint64_t) inv;
	tmp1 *= (uint64_t) p;
	mpz_set_uint64 (tmpz, tmp1);
	mpz_mul (lambda, lambda, tmpz); 
	mpz_add (lambda, lambda, rz[j]); /* now lambda^d = N (mod p^2) */
	/* subtract m0 to get roots of (m0+r)^d = N (mod p^2) */
	mpz_sub (lambda, lambda, m0);
	mpz_set_uint64 (tmpz, pp);
	mpz_fdiv_r (rz[j], lambda, tmpz);
	r[j] = mpz_get_uint64 (rz[j]);
      }

    for (j = 0; j < n; j++)
      mpz_clear (rz[j]);
    free (rz);
    mpz_clear (ppz);
    mpz_clear (tmpz);
  }

  mpz_clear (tmp);
  mpz_clear (lambda);
}

void
roots_lift_sq (uint64_t *r, mpz_t N, unsigned long d, unsigned long p, unsigned long n)
{
  uint64_t pp;
  unsigned long j, inv;
  mpz_t tmp, lambda;
  mpz_init (tmp);
  mpz_init (lambda);
  pp = (uint64_t) p;
  pp *= (uint64_t) p;

  if (sizeof (unsigned long) == 8) {
    for (j = 0; j < n; j++) {
	/* we have for r=r[j]: r^d = N (mod p), lift mod p^2:
	   (r+lambda*p)^d = N (mod p^2) implies
	   r^d + d*lambda*p*r^(d-1) = N (mod p^2)
	   lambda = (N - r^d)/(p*d*r^(d-1)) mod p */
	mpz_ui_pow_ui (tmp, r[j], d - 1);
	mpz_mul_ui (lambda, tmp, r[j]);    /* lambda = r^d */
	mpz_sub (lambda, N, lambda);
	mpz_divexact_ui (lambda, lambda, p);
	mpz_mul_ui (tmp, tmp, d);         /* tmp = d*r^(d-1) */
	inv = invert (mpz_fdiv_ui (tmp, p), p);
	mpz_mul_ui (lambda, lambda, inv * p); /* inv * p fits in 64 bits if
						 p < 2^32 */
	mpz_add_ui (lambda, lambda, r[j]); /* now lambda^d = N (mod p^2) */

	r[j] = mpz_fdiv_ui (lambda, pp);
      }
  }
  else {

    uint64_t tmp1;
    mpz_t ppz, *rz, tmpz;
    rz = (mpz_t*) malloc (n * sizeof (mpz_t));
    mpz_init (ppz);
    mpz_init (tmpz);
    for (j = 0; j < n; j++) {
      mpz_init_set_ui (rz[j], 0UL);
      mpz_set_uint64 (rz[j], r[j]);

    }

    for (j = 0; j < n; j++) {
	mpz_pow_ui (tmp, rz[j], d - 1);
	mpz_mul (lambda, tmp, rz[j]);    /* lambda = r^d */
	mpz_sub (lambda, N, lambda);
	mpz_divexact_ui (lambda, lambda, p);
	mpz_mul_ui (tmp, tmp, d);         /* tmp = d*r^(d-1) */
	inv = invert (mpz_fdiv_ui (tmp, p), p);
	tmp1 = (uint64_t) inv;
	tmp1 *= (uint64_t) p;
	mpz_set_uint64 (tmpz, tmp1);
	mpz_mul (lambda, lambda, tmpz); 
	mpz_add (lambda, lambda, rz[j]); /* now lambda^d = N (mod p^2) */
	/* subtract m0 to get roots of (m0+r)^d = N (mod p^2) */

	mpz_set_uint64 (tmpz, pp);
	mpz_fdiv_r (rz[j], lambda, tmpz);
	r[j] = mpz_get_uint64 (rz[j]);
      }

    for (j = 0; j < n; j++)
      mpz_clear (rz[j]);
    free (rz);
    mpz_clear (ppz);
    mpz_clear (tmpz);
  }

  mpz_clear (tmp);
  mpz_clear (lambda);
}

/* first combination: 0, 1, 2, 3, \cdots */
void
first_comb ( unsigned long k,
             unsigned long *r )
{
  unsigned long i;
  for (i = 0; i < k; ++i)
    r[i] = i;
}


/* next combination */
unsigned long
next_comb ( unsigned long n,
            unsigned long k,
            unsigned long *r )
{
  unsigned long j;

  /* if the last combination */
  if (r[0] == (n - k)) {
    return k;
  }

  /* r[k-1] doesnot equal to the n-1, just increase it */
  j = k - 1;
  if (r[j] < (n-1)) {
    r[j] ++;
    return j;
  }

  /* find which one we should increase */
  while ( (r[j] - r[j-1]) == 1)
    j --;

  unsigned long ret = j - 1;
  unsigned long z = ++r[j-1];

  while (j < k) {
    r[j] = ++z;
    j ++;
  }
  return ret;
}


/* debug */
void
print_comb ( unsigned long k,
             unsigned long *r )
{
  unsigned long i;
  for (i = 0; i < k; i ++)
    fprintf (stderr, "%lu ", r[i]);
  fprintf (stderr, "\n");
}


/* return number of n choose k */
unsigned long
binom ( unsigned long n,
        unsigned long k )
{
  if (k > n)
    return 0;
  if (k == 0 || k == n)
    return 1;
  if (2*k > n)
    k = n - k;

  unsigned long tot = n - k + 1, f = tot, i;
  for (i = 2; i <= k; i++) {
    f ++;
    tot *= f;
    tot /= i;
  }
  return tot;
}
void
comp_sq_roots_ext ( header_t header,
                qroots_t SQ_R )
{
  unsigned long i, q, nrq;
    uint64_t *rq;

  rq = (uint64_t*) malloc (header->d * sizeof (uint64_t));
  if (rq == NULL)
  {
    fprintf (stderr, "Error, cannot allocate memory in comp_sq_q\n");
    exit (1);
  }

  /* prepare the special-q's */
#ifdef SPECIAL_Q_EXTENDED
  for (i = 1; (q = SPECIAL_Q_EXT[i]) != 0 ; i++)
  {
    if ((header->d * header->ad) % q == 0)
      continue;

    if ( mpz_fdiv_ui (header->Ntilde, q) == 0 )
      continue;

    nrq = roots_mod_uint64 (rq, mpz_fdiv_ui (header->Ntilde, q), header->d, q);
    roots_lift (rq, header->Ntilde, header->d, header->m0, q, nrq);



    qroots_add (SQ_R, q, nrq, rq);
  }

#else
    for (i = 1; (q = SPECIAL_Q[i]) != 0 ; i++)
  {
    if ((header->d * header->ad) % q == 0)
      continue;

	/* included*/

	if (((header->d-2) * header->ad) % q == 0)
		continue; 
    if ( mpz_fdiv_ui (header->Ntilde, q) == 0 )
      continue;

    nrq = roots_mod_uint64 (rq, mpz_fdiv_ui (header->Ntilde, q), header->d, q);
    roots_lift (rq, header->Ntilde, header->d, header->m0, q, nrq);



    qroots_add (SQ_R, q, nrq, rq);
  }


#endif



  /* Reorder R entries by nr. It is safe to comment it. */
  qroots_rearrange (SQ_R);

  free(rq);
  qroots_realloc (SQ_R, SQ_R->size); /* free unused space */
}
/* prepare special-q's roots */
void
comp_sq_roots ( header_t header,
                qroots_t SQ_R )
{
  unsigned long i, q, nrq;
  uint64_t *rq;

  rq = (uint64_t*) malloc (header->d * sizeof (uint64_t));
  if (rq == NULL)
  {
    fprintf (stderr, "Error, cannot allocate memory in comp_sq_q\n");
    exit (1);
  }

  /* prepare the special-q's */
  for (i = 1; (q = SPECIAL_Q[i]) != 0 ; i++)
  {
    if ((header->d * header->ad) % q == 0)
      continue;

    if ( mpz_fdiv_ui (header->Ntilde, q) == 0 )
      continue;

    nrq = roots_mod_uint64 (rq, mpz_fdiv_ui (header->Ntilde, q), header->d, q);
    roots_lift (rq, header->Ntilde, header->d, header->m0, q, nrq);

#ifdef DEBUG_POLYSELECT2L
    unsigned int j = 0;
    mpz_t r1, r2;
    mpz_init (r1);
    mpz_init (r2);
    mpz_set (r1, header->Ntilde);
    mpz_mod_ui (r1, r1, q*q);

    gmp_fprintf (stderr, "Ntilde: %Zd, Ntilde (mod %u): %Zd\n", 
                header->Ntilde, q*q, r1);

    for (j = 0; j < nrq; j ++) {
      mpz_set (r2, header->m0);

      mpz_add_ui (r2, r2, rq[j]);
      mpz_pow_ui (r2, r2, header->d);
      mpz_mod_ui (r2, r2, q*q);

      if (mpz_cmp (r1, r2) != 0) {
        fprintf (stderr, "Root computation wrong in comp_sq_roots().\n");
        fprintf (stderr, "q: %lu, rq: %lu\n", q, rq[j]);
        exit(1);
      }
    }

    mpz_clear (r1);
    mpz_clear (r2);
#endif

    qroots_add (SQ_R, q, nrq, rq);
  }

  /* Reorder R entries by nr. It is safe to comment it. */
  qroots_rearrange (SQ_R);

  free(rq);
  qroots_realloc (SQ_R, SQ_R->size); /* free unused space */
}


/* given individual q's, return crted rq */
uint64_t
return_q_rq ( qroots_t SQ_R,
              unsigned long *idx_q,
              unsigned long k,
              mpz_t qqz,
              mpz_t rqqz,
              unsigned long lq )
{
  unsigned long i, j, idv_q[k], idv_rq[k];
  uint64_t q = 1;

  /* q and roots */
  for (i = 0; i < k; i ++) {
    idv_q[i] = SQ_R->q[idx_q[i]];
    q = q * idv_q[i];
    j = rand() % SQ_R->nr[idx_q[i]];
    idv_rq[i] = SQ_R->roots[idx_q[i]][j];
  }

#if 0
  for (i = 0; i < k; i ++) {
    fprintf (stderr, "(%lu:%lu) ", idv_q[i], idv_rq[i]);
  }
  //gmp_fprintf (stderr, "%Zd\n", rqqz);
#endif

  /* crt roots */
  crt_sq (qqz, rqqz, idv_q, idv_rq, lq);

  return q;
}


/* given individual q's, return \product q and q^2 only, no rq */
uint64_t
return_q_norq ( qroots_t SQ_R,
                unsigned long *idx_q,
                unsigned long k,
                mpz_t qqz )
{
  unsigned long i;
  uint64_t q = 1;

  for (i = 0; i < k; i ++)
    q = q * SQ_R->q[idx_q[i]];
  mpz_set_uint64 (qqz, q);
  mpz_mul (qqz, qqz, qqz);
  return q;
}

void
return_q_norq_mpz ( qroots_t SQ_R,
                unsigned long *idx_q,
                unsigned long k,
                mpz_t qqz, 
				mpz_t q_new,
				pcollision_t pcollision)
{
  unsigned long i;
	/*
  unsigned long j;



SQ_R->q[2]^=SQ_R->q[4];
SQ_R->q[4]^=SQ_R->q[2];
SQ_R->q[2]^=SQ_R->q[4]; // 2=79

SQ_R->nr[2]^=SQ_R->nr[4];
SQ_R->nr[4]^=SQ_R->nr[2];
SQ_R->nr[2]^=SQ_R->nr[4];

 for (j = 0; j < MAXDEGREE; j ++)
 {
    SQ_R->roots[2][j] ^= SQ_R->roots[4][j];
	SQ_R->roots[4][j] ^= SQ_R->roots[2][j];
	SQ_R->roots[2][j] ^= SQ_R->roots[4][j];

 }
SQ_R->q[3]^=SQ_R->q[5];
SQ_R->q[5]^=SQ_R->q[3];
SQ_R->q[3]^=SQ_R->q[5]; // 3= 97

SQ_R->nr[3]^=SQ_R->nr[5];
SQ_R->nr[5]^=SQ_R->nr[3];
SQ_R->nr[3]^=SQ_R->nr[5];

 for (j = 0; j < MAXDEGREE; j ++)
 {
      SQ_R->roots[3][j] ^= SQ_R->roots[5][j];
	SQ_R->roots[5][j] ^= SQ_R->roots[3][j];
	SQ_R->roots[3][j] ^= SQ_R->roots[5][j];

 }


SQ_R->q[4]^=SQ_R->q[6];
SQ_R->q[6]^=SQ_R->q[4];
SQ_R->q[4]^=SQ_R->q[6]; //4-103

SQ_R->nr[4]^=SQ_R->nr[6];
SQ_R->nr[6]^=SQ_R->nr[4];
SQ_R->nr[4]^=SQ_R->nr[6];

 for (j = 0; j < MAXDEGREE; j ++)
 {
      SQ_R->roots[4][j] ^= SQ_R->roots[6][j];
	SQ_R->roots[6][j] ^= SQ_R->roots[4][j];
	SQ_R->roots[4][j] ^= SQ_R->roots[6][j];

 }


SQ_R->q[5]^=SQ_R->q[10];
SQ_R->q[10]^=SQ_R->q[5];
SQ_R->q[5]^=SQ_R->q[10]; //5 = 331

  SQ_R->nr[5]^=SQ_R->nr[10];
SQ_R->nr[10]^=SQ_R->nr[5];
SQ_R->nr[5]^=SQ_R->nr[10];

 for (j = 0; j < MAXDEGREE; j ++)
 {
      SQ_R->roots[5][j] ^= SQ_R->roots[10][j];
	SQ_R->roots[10][j] ^= SQ_R->roots[5][j];
	SQ_R->roots[5][j] ^= SQ_R->roots[10][j];

 }

SQ_R->q[6]^=SQ_R->q[12];
SQ_R->q[12]^=SQ_R->q[6];
SQ_R->q[6]^=SQ_R->q[12];

SQ_R->nr[6]^=SQ_R->nr[12];
SQ_R->nr[12]^=SQ_R->nr[6];
SQ_R->nr[6]^=SQ_R->nr[12];

// 6 = 601



 for (j = 0; j < MAXDEGREE; j ++)
 {
      SQ_R->roots[6][j] ^= SQ_R->roots[12][j];
	SQ_R->roots[12][j] ^= SQ_R->roots[6][j];
	SQ_R->roots[6][j] ^= SQ_R->roots[12][j];
 }



   SQ_R->q[7]^=SQ_R->q[13];
SQ_R->q[13]^=SQ_R->q[7];
SQ_R->q[7]^=SQ_R->q[13];

SQ_R->nr[7]^=SQ_R->nr[13];
SQ_R->nr[13]^=SQ_R->nr[7];
SQ_R->nr[7]^=SQ_R->nr[13];

// 6 = 601



 for (j = 0; j < MAXDEGREE; j ++)
 {
      SQ_R->roots[7][j] ^= SQ_R->roots[13][j];
	SQ_R->roots[13][j] ^= SQ_R->roots[7][j];
	SQ_R->roots[7][j] ^= SQ_R->roots[13][j];
 }


 //7 = 619

SQ_R->q[8]^=SQ_R->q[17];
SQ_R->q[17]^=SQ_R->q[8];
SQ_R->q[8]^=SQ_R->q[17];

SQ_R->nr[8]^=SQ_R->nr[17];
SQ_R->nr[17]^=SQ_R->nr[8];
SQ_R->nr[8]^=SQ_R->nr[17];

// 6 = 601



 for (j = 0; j < MAXDEGREE; j ++)
 {
      SQ_R->roots[8][j] ^= SQ_R->roots[17][j];
	SQ_R->roots[17][j] ^= SQ_R->roots[8][j];
	SQ_R->roots[8][j] ^= SQ_R->roots[17][j];
 }

*/

  for (i = 0; i < k; i ++)

	  mpz_mul_ui(q_new,q_new,SQ_R->q[idx_q[i]]);

    for (i = 0; i < k; i ++)
		pcollision->q[i]=SQ_R->q[idx_q[i]];

#ifdef DEBUG_POLYSEARCH

	for(i=0; i<k; i++)
		printf(" q[%lu] : %lu  \n", i, pcollision->q[i]);



#endif
  mpz_set (qqz, q_new);
  mpz_mul (qqz, qqz, qqz);



}
void pgroup_set (pgroup_t pgroup, header_t header, unsigned long *primes,int len)
{
	int i, nr;

	pgroup->size = len;
	pgroup->q = malloc (len*sizeof (uint64_t));
	pgroup->roots = malloc (len*header->d*sizeof(uint64_t));
	pgroup->nr = malloc (len*sizeof (uint64_t));
	for(i=0; i<len; i++)
		pgroup->roots[i] = malloc (len*header->d*sizeof(uint64_t));


	/* Calculate x^6 mod p */
	for(i=0; i<len; i++)
	{
		pgroup->q[i]=primes[i];
		nr=roots_mod_uint64 (pgroup->roots[i], mpz_fdiv_ui (header->Ntilde, primes[i]), header->d, primes[i]); 
		printf( " Number of Roots : %d \n", nr);
		roots_lift_sq (pgroup->roots[i], header->Ntilde, header->d, primes[i], nr);
		pgroup->nr[i]=nr;
		pgroup->total*=nr;
	}

	/* Calculate square of product of primes */
	for(i=0; i<len; i++)
		mpz_mul_ui (pgroup->p_mul, pgroup->p_mul, primes[i]);

	mpz_mul (pgroup->p_sq, pgroup->p_mul, pgroup->p_mul);

	/* Alloc memory for CRT'd roots */

	pgroup->crt_r = malloc (pgroup->total*sizeof(mpz_t));

	for(i=0; i<pgroup->total; i++)
		mpz_init_set_ui (pgroup->crt_r[i],0);

}


int check_root ( header_t header, mpz_t root, mpz_t modulus)
{
	mpz_t  tmp, m_root, m_ntilde;

	int check=0;

	mpz_init (tmp);
	mpz_init (m_root);
	mpz_init (m_ntilde);

		if (header->d==4)
	{
		mpz_mul (tmp, root,root); //r^2
		mpz_mul (tmp, tmp, tmp); // tmp=r^4

	}
	
	if (header->d==5)
	{
		mpz_mul (tmp, root,root); //r^2
		mpz_mul (tmp, tmp, tmp); // tmp=r^4
		mpz_mul (tmp, tmp,root);

	}




	if (header->d==6)
	{
		mpz_mul (tmp, root,root); //r^2
		mpz_mul (tmp, tmp, tmp); // tmp=r^4
		mpz_mul (tmp, tmp,root);
		mpz_mul (tmp, tmp,root);
	}

	
	if (header->d==7)
	{
		mpz_mul (tmp, root,root); //r^2
		mpz_mul (tmp, tmp, tmp); // tmp=r^4
		mpz_mul (tmp, tmp,root);// tmp=r^5
		mpz_mul (tmp, tmp,root);
		mpz_mul (tmp, tmp,root);
	}

	if (header->d==8)
	{
		mpz_mul (tmp, root,root); //r^2
		mpz_mul (tmp, tmp, tmp); // tmp=r^4
		mpz_mul (tmp, tmp, tmp);// tmp=r^8
	
	}


	mpz_mod (m_root, tmp, modulus); // mroot= r^6 mod q^2
	mpz_mod (m_ntilde, header->Ntilde, modulus);

	//gmp_printf( "m_root : %Zd \n", m_root);
	//gmp_printf( "m_ntil : %Zd \n", m_ntilde);
	mpz_sub (m_root, m_root, m_ntilde);
	check=mpz_divisible_p (m_root, modulus);
	//check = mpz_cmp (m_root, m_ntilde);


	mpz_clear (tmp);
	mpz_clear (m_root);
	mpz_clear (m_ntilde);

	return  check;

}

void CRT_two (header_t header, pgroup_t pgroup)

{


	int i, j, iter=0, check;

	ASSERT (pgroup->size==2);
	mpz_t tmp, mod_tmp[2], inv_tmp[2];
	mpz_t tmp2, tmp3;

	mpz_init (tmp2);
	mpz_init (tmp3);
	mpz_init (tmp);


	for(i=0; i<2; i++)
	{
		mpz_init (mod_tmp[i]);
		mpz_init (inv_tmp[i]);

	}




	/* Calculus inverses */

	for(i=0; i<2; i++)
	{
		mpz_set_ui (tmp, pgroup->q[i]);
		mpz_mul (tmp, tmp, tmp);  // tmp=p^2

		mpz_divexact (mod_tmp[i], pgroup->p_sq, tmp); // mod_tmp[i]=M/mi		
		mpz_invert (inv_tmp[i], mod_tmp[i], tmp); // inv_tmp = M/mi ^(-1) mod mi

	}


	for(i=0; i<pgroup->nr[0]; i++)
	{
		mpz_set_ui (tmp2, pgroup->roots[0][i]);
		mpz_mul (tmp2, tmp2, mod_tmp[0]);
		mpz_mul (tmp2, tmp2, inv_tmp[0]);
		for(j=0; j<pgroup->nr[1]; j++)
		{
			mpz_set_ui (tmp3, pgroup->roots[1][j]);
			mpz_mul (tmp3, tmp3, mod_tmp[1]);
			mpz_mul (tmp3, tmp3, inv_tmp[1]);

			mpz_add (pgroup->crt_r[iter], tmp2, tmp3);
			mpz_mod (pgroup->crt_r[iter], pgroup->crt_r[iter], pgroup->p_sq);

			check=check_root (header, pgroup->crt_r[iter], pgroup->p_sq); 
			if(check==0) printf (" ERROR IN CRT TWO \n");

			iter ++;

		}
	}

	mpz_clear (tmp2);
	mpz_clear (tmp3);
	mpz_clear (tmp);


	for(i=0; i<2; i++)
	{
		mpz_clear (mod_tmp[i]);
		mpz_clear (inv_tmp[i]);

	}


}


void CRT_three (header_t header, pgroup_t pgroup)

{


	int i, j, k, iter=0, check;

	ASSERT (pgroup->size==3);
	mpz_t tmp, mod_tmp[3], inv_tmp[3];
	mpz_t tmp2, tmp3, tmp4;

	mpz_init (tmp2);
	mpz_init (tmp3);
	mpz_init (tmp4);
	mpz_init (tmp);


	for(i=0; i<3; i++)
	{
		mpz_init (mod_tmp[i]);
		mpz_init (inv_tmp[i]);

	}




	/* Calculus inverses */

	for(i=0; i<3; i++)
	{
		mpz_set_ui (tmp, pgroup->q[i]);
		mpz_mul (tmp, tmp, tmp);  // tmp=p^2

		mpz_divexact (mod_tmp[i], pgroup->p_sq, tmp); // mod_tmp[i]=M/mi		
		mpz_invert (inv_tmp[i], mod_tmp[i], tmp); // inv_tmp = M/mi ^(-1) mod mi

	}


	for(i=0; i<pgroup->nr[0]; i++)
	{
		mpz_set_ui (tmp2, pgroup->roots[0][i]);
		mpz_mul (tmp2, tmp2, mod_tmp[0]);
		mpz_mul (tmp2, tmp2, inv_tmp[0]);
		for(j=0; j<pgroup->nr[1]; j++)
		{
			mpz_set_ui (tmp3, pgroup->roots[1][j]);
			mpz_mul (tmp3, tmp3, mod_tmp[1]);
			mpz_mul (tmp3, tmp3, inv_tmp[1]);

			for(k=0; k<pgroup->nr[2]; k++)
			{
				mpz_set_ui (tmp4, pgroup->roots[2][k]);
				mpz_mul (tmp4, tmp4, mod_tmp[2]);
				mpz_mul (tmp4, tmp4, inv_tmp[2]);

				mpz_add (pgroup->crt_r[iter], tmp2, tmp3);
				mpz_add (pgroup->crt_r[iter], pgroup->crt_r[iter], tmp4);
				mpz_mod (pgroup->crt_r[iter], pgroup->crt_r[iter], pgroup->p_sq);
				check=check_root (header, pgroup->crt_r[iter], pgroup->p_sq); 
				if(check==0) printf (" ERROR IN CRT THREE \n");
									 
				iter ++;
			}
		}
	}

	mpz_clear (tmp2);
	mpz_clear (tmp3);
	mpz_clear (tmp4);
	mpz_clear (tmp);


	for(i=0; i<3; i++)
	{
		mpz_clear (mod_tmp[i]);
		mpz_clear (inv_tmp[i]);

	}


}


void CRT_four (header_t header, pgroup_t pgroup)

{


	int h, i, j, k, iter=0;
	mpz_t tmp, mod_tmp[4], inv_tmp[4];
	mpz_t tmp2, tmp3, tmp4, tmp5;

	mpz_init (tmp2);
	mpz_init (tmp3);
	mpz_init (tmp4);
	mpz_init (tmp5);
	mpz_init (tmp);


	for(i=0; i<4; i++)
	{
		mpz_init (mod_tmp[i]);
		mpz_init (inv_tmp[i]);

	}




	/* Calculus inverses */

	for(i=0; i<4; i++)
	{
		mpz_set_ui (tmp, pgroup->q[i]);
		mpz_mul (tmp, tmp, tmp);  // tmp=p^2

		mpz_divexact (mod_tmp[i], pgroup->p_sq, tmp); // mod_tmp[i]=M/mi		
		mpz_invert (inv_tmp[i], mod_tmp[i], tmp); // inv_tmp = M/mi ^(-1) mod mi

	}


	for(i=0; i<pgroup->nr[0]; i++)
	{
		mpz_set_ui (tmp2, pgroup->roots[0][i]);
		mpz_mul (tmp2, tmp2, mod_tmp[0]);
		mpz_mul (tmp2, tmp2, inv_tmp[0]);
		for(j=0; j<pgroup->nr[1]; j++)
		{
			mpz_set_ui (tmp3, pgroup->roots[1][j]);
			mpz_mul (tmp3, tmp3, mod_tmp[1]);
			mpz_mul (tmp3, tmp3, inv_tmp[1]);

			for(k=0; k<pgroup->nr[2]; k++)
			{
				mpz_set_ui (tmp4, pgroup->roots[2][k]);
				mpz_mul (tmp4, tmp4, mod_tmp[2]);
				mpz_mul (tmp4, tmp4, inv_tmp[2]);

				for(h=0; h<pgroup->nr[3]; h++)
				{
					mpz_set_ui (tmp5, pgroup->roots[3][h]);
					mpz_mul (tmp5, tmp5, mod_tmp[3]);
					mpz_mul (tmp5, tmp5, inv_tmp[3]);

					mpz_add (pgroup->crt_r[iter], tmp2, tmp3);
					mpz_add (pgroup->crt_r[iter], pgroup->crt_r[iter], tmp4);
					mpz_add (pgroup->crt_r[iter], pgroup->crt_r[iter], tmp5);
					mpz_mod (pgroup->crt_r[iter], pgroup->crt_r[iter], pgroup->p_sq);
					if(check_root (header, pgroup->crt_r[iter], pgroup->p_sq)==0)  printf (" ERROR IN CRT FOUR \n");
					iter ++;


				}
			}
		}
	}

	mpz_clear (tmp2);
	mpz_clear (tmp3);
	mpz_clear (tmp4);
	mpz_clear (tmp5);
	mpz_clear (tmp);


	for(i=0; i<4; i++)
	{
		mpz_clear (mod_tmp[i]);
		mpz_clear (inv_tmp[i]);

	}


}

void adjustMultiplier (ppselect_t pselect, mpz_t root)
{
	mpz_t k, tmp[3];
	mpz_t sub1, sub2;
	int i, min=0;

	mpz_init (k);
	mpz_init (sub1);
	mpz_init (sub2);


	for(i=0; i<3; i++)
		mpz_init (tmp[i]);

	mpz_sub (k, pselect->r_mtilde, root);
	mpz_tdiv_q (k, k, pselect->modulus); // k

	mpz_mul (tmp[0], k, pselect->modulus);
	mpz_add (tmp[0], tmp[0], root);
	mpz_sub (tmp[1], tmp[0], pselect->modulus);
	mpz_add (tmp[2], tmp[0], pselect->modulus);

	mpz_sub (sub1, pselect->r_mtilde, tmp[0]);
	mpz_sub (sub2, pselect->r_mtilde, tmp[1]);
	mpz_sub (k, pselect->r_mtilde, tmp[2]);

	mpz_abs(sub1,sub1);
	mpz_abs(sub2,sub2);
	mpz_abs(k,k);
	if (mpz_cmp(sub1,sub2)<0) // sub1 is small
	{
		if (mpz_cmp(k, sub1)<0) //k is small
			min=2;
		else min=0;

	}

	else                            //sub2 small
	{
		if (mpz_cmp (k, sub2)<0)
			min=1;
		else min=2;

	}

	mpz_set (root,tmp[min]);

	mpz_clear (k);
	mpz_clear (sub1);
	mpz_clear (sub2);


	for(i=0; i<3; i++)
		mpz_clear (tmp[i]);



}

void pselect_set (ppselect_t pselect, header_t header)
{
	mpz_set_ui (pselect->dad, header->d);
	mpz_mul_ui (pselect->dad, pselect->dad, header->ad);
	mpz_root (pselect->r_mtilde, header->Ntilde, header->d);
	mpz_set (pselect->sub_min, pselect->r_mtilde);


}


void
sorted_insert_logmu(btmp_t btmp, ppselect_t pselect, mpz_t *f, mpz_t *g, double value, int KEEP, unsigned int degree)
{
  size_t k=0;
 
//printf (" lognorm : %1.2f \n", value);
  if (value < btmp->b_log[KEEP-1]) {
	  for(k = KEEP-1; (k > 0 && (value < btmp->b_log[k-1])); k--)
	  {
		  btmp->b_log[k] = btmp->b_log[k-1];
		  mpz_set (btmp->best_root[k], btmp->best_root[k-1]);
		  btmp->b_p1[k]=btmp->b_p1[k-1];
		  btmp->b_p2[k]=btmp->b_p2[k-1];
		  mpz_set(btmp->q[k], btmp->q[k-1]);
			mpz_set(btmp->sub_min[k], btmp->sub_min[k-1]);
		  //	mpz_set (bselect->sub_min, pselect->sub_min);
		  for(unsigned int i=0; i<degree+1; i++)
			  mpz_set(btmp->f[k][i], btmp->f[k-1][i]);

		  mpz_set (btmp->g[k][0], btmp->g[k-1][0]);
		  mpz_set (btmp->g[k][1], btmp->g[k-1][1]);


	  }
	  btmp->b_log[k] = value;



	  mpz_set (btmp->best_root[k], pselect->best_root);
	  btmp->b_p1[k]=pselect->b_p1;
	  btmp->b_p2[k]=pselect->b_p2;
	  mpz_set(btmp->q[k], pselect->q);
		mpz_set(btmp->sub_min[k], pselect->sub_min);
	  //	mpz_set (bselect->sub_min, pselect->sub_min);
	  for(unsigned int i=0; i<degree+1; i++)
		  mpz_set(btmp->f[k][i], f[i]);

	  mpz_set (btmp->g[k][0], g[0]);
	  mpz_set (btmp->g[k][1], g[1]);


  }

//for( int i=0; i<KEEP-1; i++)
// printf("SAVED : %1.2f \n",btmp->b_log[i]);
//
// printf("SAVED : %1.2f \n",btmp->b_log[KEEP-1]);
// for(int k=0; k<50; k++)
// {
//
//	  if( btmp->b_log[k] <10)
//	  {
//		  btmp->b_log[k] = 999.99;
//		  for(unsigned int i=0; i<degree+1; i++)
//			  mpz_set_ui(btmp->f[k][i], 0);
//
//		  mpz_set_ui(btmp->g[k][0],0);
//		  mpz_set_ui(btmp->g[k][1],0);
//
//	  }
// }



}