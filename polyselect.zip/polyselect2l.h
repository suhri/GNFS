#ifndef POLYSELECT2L_H
#define POLYSELECT2L_H

#include "polyselect2l_str.h"
#include "polyselect2l_arith.h"
#include "modredc_ul.h"

#endif
