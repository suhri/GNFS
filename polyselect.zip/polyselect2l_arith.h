#ifndef POLYSELECT2L_ARITH_H
#define POLYSELECT2L_ARITH_H

#include "polyselect2l_str.h"

/* declarations */

unsigned long invert (unsigned long, unsigned long);

void roots_lift (uint64_t*, mpz_t, unsigned long, mpz_t, unsigned long,
                 unsigned long int);
void roots_lift_sq (uint64_t *r, mpz_t N, unsigned long d,   unsigned long p, unsigned long n);

void first_comb (unsigned long, unsigned long *);

unsigned long next_comb (unsigned long, unsigned long, unsigned long *);

void print_comb (unsigned long, unsigned long *);

unsigned long binom (unsigned long, unsigned long);

void comp_sq_roots (header_t, qroots_t);
void comp_sq_roots_ext (header_t, qroots_t);

void crt_sq (mpz_t, mpz_t, unsigned long *, unsigned long *, unsigned long);

uint64_t return_q_rq (qroots_t, unsigned long *, unsigned long,
                      mpz_t, mpz_t, unsigned long);

uint64_t return_q_norq (qroots_t, unsigned long *, unsigned long, mpz_t);
void
return_q_norq_mpz ( qroots_t SQ_R,
                unsigned long *idx_q,
                unsigned long k,
                mpz_t qqz, 
				mpz_t q_new,
				pcollision_t pcollision);
void sorted_insert_logmu(btmp_t btmp, ppselect_t pselect, mpz_t *f, mpz_t *g, double value, int,unsigned int);

void pgroup_set (pgroup_t pgroup, header_t header, unsigned long *primes,int len);
void pselect_set (ppselect_t pselect, header_t header);

int check_root ( header_t header, mpz_t root, mpz_t modulus);
void CRT_two (header_t header, pgroup_t pgroup);
void CRT_three (header_t header, pgroup_t pgroup);
void CRT_four ( header_t header, pgroup_t pgroup);
void adjustMultiplier (ppselect_t pselect, mpz_t root);

#endif
