#ifndef PURGEDFILE_H_
#define PURGEDFILE_H_
#include <stdio.h>
#include <stdint.h>

void purgedfile_read_firstline (const char *, uint64_t *, uint64_t *);

#endif	/* PURGEDFILE_H_ */
